# Google-Data-Analytics-Capstone
## A case study on the cyclistic data set
This repository contains an analysis done for the capstone project of the Google Data Analytics Professional Certificate course offered on Coursera. In this case study, I used data from a fictional bike rental company based in Chicago, Cyclist, to try to determine and understand the main differences between annual members and casual rider. With such insights, I was able to deliver recommendations, with which the company has developed a marketing campaign aimed at converting casual riders to annual members, and hence maximizing the growth of the company.



![154794904-df924ea1-f2b8-4d4e-a04f-d39b9ad8b6f4](https://user-images.githubusercontent.com/99217835/156901337-b969a60e-5d7e-47c6-9a47-bdc970a2b262.png)

